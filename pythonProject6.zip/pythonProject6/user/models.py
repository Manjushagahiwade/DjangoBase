from django.db import models

from django.contrib.auth.models import AbstractUser
from user.maneger import UserManager
from django.utils.translation import gettext_lazy as _
from django.conf import settings
# Create your models here.

class User(AbstractUser):
    username = None
    email = models.EmailField(unique=True)
    contact_no = models.CharField(max_length=250)
    profile_pic = models.ImageField(blank=True, null=True, upload_to='images')

    date_created = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []