from django import forms
from django.contrib.auth.forms import UserCreationForm

from user.models import User


class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    profile_image = forms.ImageField(required=False)

    class Meta:
        model = User
        fields = ("first_name", "last_name", "email","contact_no")

    def __init__(self, *args, **kwargs):
        super(UserRegistrationForm, self).__init__(*args, **kwargs)

        self.fields['first_name'].widget.attrs['class'] = 'form-control'
        self.fields['first_name'].widget.attrs['pattern'] = '[a-zA-Z]+'
        self.fields['first_name'].required = True

        self.fields['last_name'].widget.attrs['class'] = 'form-control'
        self.fields['last_name'].widget.attrs['pattern'] = '[a-zA-Z]+'
        self.fields['last_name'].required = True

        self.fields['email'].widget.attrs['class'] = 'form-control'
        self.fields['profile_image'].widget.attrs['class'] = 'form-control'

        self.fields['first_name'].widget.attrs['placeholder'] = 'First Name'
        self.fields['last_name'].widget.attrs['placeholder'] = 'Last Name'
        self.fields['email'].widget.attrs['placeholder'] = 'Enter your email'

