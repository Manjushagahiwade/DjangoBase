from django.db import models


# Create your models here.

class Post(models.Model):
    title = models.CharField(max_length=256, blank=True, null=True)
    content = models.CharField(max_length=256, blank=True, null=True)
    author_name = models.CharField(max_length=256, blank=True, null=True)
    is_published = models.BooleanField(default=False)

    date_created = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    date_update = models.DateTimeField(auto_now=True, null=True, blank=True)


