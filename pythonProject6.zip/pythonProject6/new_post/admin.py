from django.contrib import admin
from new_post.models import Post
# Register your models here.

admin.site.register(Post)