from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.views import generic
from new_post.models import Post
from new_post.forms import PostCreateForm


# Create your views here.

class PostCreateView(LoginRequiredMixin,generic.CreateView):
    model = Post
    template_name = "post/create.html"
    form_class = PostCreateForm
    success_url = "/"


class PostListView(generic.ListView):
    model = Post
    template_name = "post/list.html"
    context_object_name = "objects"
    queryset = Post.objects.filter(is_published=True)


class PostUpdateView(LoginRequiredMixin, generic.UpdateView):
    model = Post
    template_name = "post/update.html"
    form_class = PostCreateForm
    success_url = "/"


class PostDeleteView(LoginRequiredMixin, generic.DeleteView):
    model = Post
    success_url = "/"

    def get(self, request, *args, **kwargs):
        id = kwargs.get('pk')
        post = Post.objects.filter(id=id)
        post.delete()

        return HttpResponseRedirect('/')
