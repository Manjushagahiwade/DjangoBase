from django import forms
from new_post.models import Post


class PostCreateForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        for field in self.fields.keys():
            self.fields[field].widget.attrs.update(
                {
                    "class": "form-control", "autocomplete": "off",
                    "placeholder": " ".join(field.title().split("_")).capitalize()
                }
            )
            self.fields['is_published'] = forms.BooleanField()

    class Meta:
        model = Post
        fields = "__all__"
